﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:		Homework 2 - String handling exercise
//	File Name:		Tools.cs
//	Description:	Used to turn a string into a multiple tokens
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Anthony Ellis, ellisah@etsu.edu, East Tennessee State University
//	Created:		Tuesday, Febuary 018, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;

namespace _2210_001_ellisanthony_homework2
{


    /// <summary>
    /// The static Methods are used to split strings up and display them.
    /// </summary>
    class Tools
    {
       
        /// <summary>Tokenizes the specified line.</summary>
        /// <param name="line">A multichar String that is  going to be tokenized</param>
        /// <param name="delims"> The String containing the delimiters to be used to tokenize the line</param>
        /// <returns>Returns the tokenized version of line as an array of strings</returns>
        public static String[] Tokenize(string line, string delims)
        {   
            Tokens Tokens = new Tokens();// Tokens is a collection that uses a list and has helper methods for adding a string token
            String Token; //Holds the currnet string token to be added
            char[] DelimChars = delims.ToCharArray(); //Array of chars made of the delims string
            int CurrDelimPosition = line.IndexOfAny(DelimChars); //the current position of the delimiter in the string
            while (CurrDelimPosition != -1)//used to find all the delimiters untill none are found
            {
                Token = line.Substring(0, CurrDelimPosition);
                Tokens.AddToken(Token);//adds first string token
                line=line.Substring(CurrDelimPosition);
                Tokens.AddToken(line.Substring(0, 1));//adds the delimiter after the token
                line = line.Substring(1);
                CurrDelimPosition = line.IndexOfAny(DelimChars);//Changes the value to the next Delimiter Position
            }
            Tokens.AddToken(line);//adds the final token
            return Tokens.GetTokens();//Calls the tokens class to get an String array of the all the tokens
        }

        /// <summary>
        /// Sets up the display.
        /// </summary>
        public static void setup()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Clear();
            Console.WriteLine("Enter text to be processed.");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Title = "CSCI 2210 - Data Structures: Homework 2 by Anthony Ellis";
            
        }

        /// <summary>
        /// Displays the specified tokens.
        /// </summary>
        /// <param name="tokens">A String Array Containing the String tokens to be displayed</param>
        public static void display(String[] tokens)
        {
            int LineNumber = 0;
            int Lines = Console.WindowHeight-5;//Number of Console Lines 
            DisplayTop();
            for (int i = 0; i<tokens.Length && tokens[i] != null; i++)//Iterates through Tokens to display
            {
                Console.WriteLine(" {0}.    {1}", i + 1, tokens[i]);//Sets format for each line
                if (LineNumber == Lines)//If Window line limit is reached
                {
                    DisplayBottom();
                    Console.Clear();
                    DisplayTop();
                    LineNumber = 0;//resets the current line in the window to 0
                }
                LineNumber++;
            }
            DisplayBottom();//Displays Bottom line for the last time
        }

        /// <summary>
        /// Sets Colors and Displays the Top then resets colors.
        /// </summary>
        private static void DisplayTop()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" No. Token");
            Console.WriteLine("---- ----");
            Console.ForegroundColor = ConsoleColor.Blue;
        }

        /// <summary>
        /// Sets Colors and Displays the bottom then resets colors.
        /// </summary>
        private static void DisplayBottom()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();//waits for any key to be pressed to continue
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
        }
        
    }

    /// <summary>
    /// Tokens Class used to Create and change a List of Strings
    /// </summary>
    class Tokens
    {

        /// <summary>
        /// Represents the String List that is used
        /// </summary>
        /// <value>The String List</value>
        List<String> tokens;

        /// <summary>
        /// Initializes a new instance of the Tokens class.
        /// </summary>
        public Tokens()
        {
            tokens = new List<String>();//creates a new String List
        }

        /// <summary>
        /// Converts String List to String Array
        /// </summary>
        /// <returns>A String Array of all tokens in current list</returns>
        public String[] GetTokens()
        {
            return tokens.ToArray();
        }

        /// <summary>
        /// Adds the token to the String list.
        /// </summary>
        /// <param name="NewToken">
        /// The new token.
        /// </param>
        public void AddToken(String NewToken)
        {

            if (String.IsNullOrWhiteSpace(NewToken))
                return;
            tokens.Add(NewToken);
        }
    }
}
